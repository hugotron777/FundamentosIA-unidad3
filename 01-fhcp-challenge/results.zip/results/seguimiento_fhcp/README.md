# Seguimiento de los 1001 grafos del FHCP

Actualizado el 17 de noviembre de 2026. Hay **638 ciclos hamiltonianos verificados** y **363 grafos pendientes**. Se han probado las 1001 instancias. La continuación añadió **605** soluciones a las 33 ya guardadas.

- [Estado por grafo](estado.csv) incluye número de vértices y aristas, intentos, mejor número de aristas faltantes cuando se midió y ruta al ciclo. Las rutas se leen desde la raíz del repositorio.
- [Registro de intentos](intentos.csv) contiene 5186 registros con método, semilla, límite, tiempo medido y resultado.
- [Ciclos de esta continuación](tours/) contiene los archivos TOUR nuevos. El estado también enlaza a los ciclos de la corrida masiva y del lote de 40.

## Corridas

| Corrida | Método | Grafos probados | Límite por grafo (s) | Ciclos nuevos |
| --- | --- | ---: | ---: | ---: |
| Corrida masiva | ACO + 2-opt, varias semillas | 338 | 4, 6 o 30 | 16 |
| Lote de 40 | ACO + 2-opt, programación entera y ramificación | 40 | 9 a 18 | 17 |
| `ramificacion_15` | Ramificación con poda por grado y cortes | 968 | 0.65 | 96 |
| `frontera_16` | Programación dinámica por frontera | 872 | 2 | 308 |
| `descomposicion_17` | Programación dinámica por descomposición, orden de grado mínimo | 564 | 3 | 190 |
| `milp_18` | Programación entera con eliminación de subciclos | 374 | 4 | 0 |
| `cortes_19` | Separadores de dos vértices y ensamble de caminos | 374 | 2.5 | 9 |
| `descomposicion_20` | Descomposición con órdenes de grado y de relleno mínimo | 365 | 3 | 2 |
| `descomposicion_amplia_21` | Descomposición con separadores más amplios | 363 | 3.5 | 0 |
| `frontera_dominantes_22` | Frontera con vértices de mayor grado al inicio | 363 | 1.5 | 0 |

Los límites se aplican a la búsqueda. Los tiempos registrados también pueden incluir lectura, preprocesamiento y validación. Cada ruta se verificó en el grafo original, incluida la arista que conecta el último vértice con el primero. Los límites agotados y las condiciones de aplicabilidad del método dejaron grafos pendientes. El método de separar por pares de vértices sigue el principio de composición descrito por Cohen y Coudert. [Descripción del enfoque](https://animations.interstices.info/interstices-graphes/index.html)

## Reanudar o auditar

Ejecuta estos comandos desde la raíz del proyecto. Las instancias están extraídas localmente en `data/instances/`. En otra copia del proyecto puedes extraerlas con `7z e data/FHCPCS.7z -odata/instances '*.hcp'`.

```bash
python -m experiments.continuar_fhcp --auditar
```

La siguiente secuencia compila los métodos nativos con GCC y lanza otra corrida.

```bash
mkdir -p /tmp/fhcp-bin
for metodo in ramificacion frontera descomposicion separadores; do
    g++ -std=c++17 -O3 "experiments/fhcp_native/$metodo.cpp" -o "/tmp/fhcp-bin/$metodo"
done
g++ -std=c++17 -O3 -DFHCP_FRONTERA_AMPLIA experiments/fhcp_native/descomposicion.cpp -o /tmp/fhcp-bin/descomposicion_amplia
g++ -std=c++17 -O3 -DFHCP_VERTICES_DOMINANTES experiments/fhcp_native/frontera.cpp -o /tmp/fhcp-bin/frontera_dominantes

python -m experiments.continuar_fhcp --corrida ramificacion_23 --metodo ramificacion \
    --ejecutable /tmp/fhcp-bin/ramificacion --limite 4 --semilla 23 --workers 7
```

El programa salta los grafos que ya tienen un ciclo. Si se interrumpe una corrida, el mismo comando retoma las instancias pendientes de ese intento. Para cambiar el presupuesto, la semilla o el método, usa un nombre de corrida nuevo.
